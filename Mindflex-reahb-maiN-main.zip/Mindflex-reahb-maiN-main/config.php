<?php

    $host= "localhost";
    $username = "root";
    $password = "";
    $dbname = "demodatabase";

    $conn= mysqli_connect($host,$username,$password,$dbname);
//     if($conn){
//         echo "good connection";

//     }
//     else{
//         echo "poor connections";
//     }
// ?>